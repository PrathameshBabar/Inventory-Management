                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <div style="width: 100%;">
                        <a href="logout.php" style="float: right;">
                            <img class="img-profile rounded-circle" width="25px" src="img/logout.ico" >
                        </a>
                        <font class="black" style="float: right;"><?php echo $username; ?> &nbsp; </font>
                    </div>

                </nav>
                <!-- End of Topbar -->