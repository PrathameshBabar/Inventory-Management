<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "vital";

$con = mysqli_connect($host, $user, $pass, $db) or die ('Connection Failed : '.$conn->connect_error);

?>